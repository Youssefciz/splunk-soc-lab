"""
AI-Assisted SOC Triage for Splunk
---------------------------------
1. Runs detection searches against Splunk (BOTSv1 dataset) through the REST API.
2. Pseudonymizes sensitive values (IPs, hosts, users) before anything leaves the lab.
3. Sends the masked results to Google Gemini for triage (severity, MITRE mapping, next steps).
4. Restores the real values locally and writes a Markdown report for a human analyst.

The AI only recommends. A human reviews and decides on every action.

Setup:
    pip install -r requirements.txt
    PowerShell:
        $env:SPLUNK_PASS="your_splunk_admin_password"
        $env:GEMINI_API_KEY="your_gemini_api_key"
        python triage.py
"""

import datetime
import json
import os
import re
import time

import splunklib.client as client
import splunklib.results as results
from google import genai
from google.genai import errors, types

# ---------------- Config ----------------
SPLUNK_HOST = os.getenv("SPLUNK_HOST", "localhost")
SPLUNK_PORT = int(os.getenv("SPLUNK_PORT", "8089"))
SPLUNK_USER = os.getenv("SPLUNK_USER", "admin")
SPLUNK_PASS = os.environ["SPLUNK_PASS"]
MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-latest")
SECONDS_BETWEEN_CALLS = 13  # stays under free tier requests-per-minute limits
MAX_ROWS_TO_AI = 50

# Test every search in the Splunk UI first and adjust field names if needed.
DETECTIONS = {
    "Web Vulnerability Scanning": {
        "description": "Sources making an unusually high number of HTTP requests to many unique URIs.",
        "spl": (
            "search index=botsv1 sourcetype=stream:http "
            "| stats count dc(uri) as unique_uris by src_ip, http_user_agent "
            "| where count > 100 | sort -count | head 10"
        ),
    },
    "Web Login Brute Force": {
        "description": "Repeated POST requests containing password fields from the same source.",
        "spl": (
            "search index=botsv1 sourcetype=stream:http http_method=POST form_data=*passwd* "
            "| stats count by src_ip, dest_ip, uri | where count > 20 | sort -count"
        ),
    },
    "IDS Alerts (Suricata)": {
        "description": "Top Suricata IDS signatures and the hosts involved.",
        "spl": (
            "search index=botsv1 sourcetype=suricata event_type=alert "
            "| stats count by alert.signature, alert.severity, src_ip, dest_ip "
            "| sort -count | head 15"
        ),
    },
    "Firewall Top Talkers": {
        "description": "Highest volume source and destination pairs in the perimeter firewall UTM logs.",
        "spl": (
            "search index=botsv1 sourcetype=fgt_utm "
            "| stats count by srcip, dstip, action | sort -count | head 15"
        ),
    },
    "Suspicious Process Execution": {
        "description": "cmd.exe or powershell.exe launches captured by Sysmon (Event ID 1).",
        "spl": (
            'search index=botsv1 sourcetype="XmlWinEventLog:Microsoft-Windows-Sysmon/Operational" '
            "(cmd.exe OR powershell.exe) "
            '| rex "<EventID>(?<EventID>\\d+)</EventID>" '
            "| search EventID=1 "
            "| rex \"Name='Image'>(?<Image>[^<]+)<\" "
            "| rex \"Name='ParentImage'>(?<ParentImage>[^<]+)<\" "
            "| rex \"Name='CommandLine'>(?<CommandLine>[^<]+)<\" "
            '| search Image IN ("*cmd.exe", "*powershell.exe") '
            "| stats count by host, ParentImage, Image, CommandLine | sort -count | head 20"
        ),
    },
}

SYSTEM_PROMPT = """You are a Tier 2 SOC analyst reviewing Splunk detection results.
Values like IP_3, HOST_1 or USER_2 are pseudonymized. Refer to them exactly as written.
Respond ONLY with valid JSON, no preamble and no code fences, in this shape:
{
  "severity": "Critical | High | Medium | Low | Informational",
  "confidence": "High | Medium | Low",
  "summary": "2-3 sentence plain-English summary",
  "attack_narrative": "what the attacker most likely did, step by step",
  "mitre_attack": [{"id": "T1110", "name": "Brute Force"}],
  "recommended_actions": ["specific action 1", "specific action 2"],
  "false_positive_notes": "what could make this benign",
  "followup_spl": "one SPL query an analyst should run next"
}"""

SEVERITY_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Informational": 4}


# ---------------- Pseudonymization ----------------
class Pseudonymizer:
    """Swaps sensitive values for consistent tokens, then swaps them back locally."""

    IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
    SENSITIVE_FIELDS = ("host", "user", "src_user", "ComputerName")

    def __init__(self):
        self.real_to_token = {}
        self.counters = {}

    def _token(self, value, kind):
        if value not in self.real_to_token:
            self.counters[kind] = self.counters.get(kind, 0) + 1
            self.real_to_token[value] = f"{kind}_{self.counters[kind]}"
        return self.real_to_token[value]

    def mask_rows(self, rows):
        masked = []
        for row in rows:
            new_row = {}
            for key, value in row.items():
                value = str(value)
                if key in self.SENSITIVE_FIELDS:
                    new_row[key] = self._token(value, key.upper())
                else:
                    new_row[key] = self.IP_RE.sub(lambda m: self._token(m.group(), "IP"), value)
            masked.append(new_row)
        return masked

    def unmask(self, text):
        # Longest tokens first so IP_10 is restored before IP_1
        for real, token in sorted(self.real_to_token.items(), key=lambda x: -len(x[1])):
            text = text.replace(token, real)
        return text


# ---------------- Splunk ----------------
def run_search(service, spl):
    stream = service.jobs.oneshot(
        spl, output_mode="json", earliest_time="0", latest_time="now", count=0
    )
    return [r for r in results.JSONResultsReader(stream) if isinstance(r, dict)]


# ---------------- AI triage ----------------
def triage(ai, name, description, rows):
    payload = json.dumps(rows[:MAX_ROWS_TO_AI], indent=1)
    prompt = (
        f"Detection: {name}\nPurpose: {description}\n"
        f"Results ({len(rows)} rows, up to {MAX_ROWS_TO_AI} shown):\n{payload}"
    )
    config = types.GenerateContentConfig(
        system_instruction=SYSTEM_PROMPT,
        response_mime_type="application/json",  # asks Gemini for pure JSON
    )

    for attempt in range(2):
        try:
            response = ai.models.generate_content(model=MODEL, contents=prompt, config=config)
            break
        except errors.APIError as e:
            if getattr(e, "code", None) == 429 and attempt == 0:
                print("    rate limited, waiting 60s and retrying...")
                time.sleep(60)
            else:
                raise

    text = (response.text or "").strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    return json.loads(text)


# ---------------- Report ----------------
def write_report(findings, path):
    findings.sort(key=lambda f: SEVERITY_ORDER.get(f[2].get("severity"), 5))
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [f"# AI-Assisted Triage Report\n\nGenerated {now} | {len(findings)} findings\n"]
    lines.append("> AI output is a recommendation. An analyst must validate before acting.\n")

    for name, row_count, r in findings:
        lines.append(f"## [{r.get('severity')}] {name}")
        lines.append(f"**Confidence:** {r.get('confidence')} | **Matching rows:** {row_count}\n")
        lines.append(f"**Summary:** {r.get('summary')}\n")
        lines.append(f"**Attack narrative:** {r.get('attack_narrative')}\n")
        mitre = ", ".join(f"{t['id']} {t['name']}" for t in r.get("mitre_attack", []))
        lines.append(f"**MITRE ATT&CK:** {mitre}\n")
        lines.append("**Recommended actions:**")
        lines += [f"- {a}" for a in r.get("recommended_actions", [])]
        lines.append(f"\n**False positive notes:** {r.get('false_positive_notes')}\n")
        lines.append(f"**Follow-up search:**\n```\n{r.get('followup_spl')}\n```\n")

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


# ---------------- Main ----------------
def main():
    service = client.connect(
        host=SPLUNK_HOST, port=SPLUNK_PORT, username=SPLUNK_USER, password=SPLUNK_PASS
    )
    ai = genai.Client()  # reads GEMINI_API_KEY
    pseudo = Pseudonymizer()
    findings = []

    for name, d in DETECTIONS.items():
        print(f"[*] {name}")
        rows = run_search(service, d["spl"])
        if not rows:
            print("    no results, skipping")
            continue
        masked = pseudo.mask_rows(rows)
        try:
            result = triage(ai, name, d["description"], masked)
        except (json.JSONDecodeError, errors.APIError) as e:
            print(f"    triage failed: {e}")
            continue
        # Restore real values locally, after the AI call
        result = json.loads(pseudo.unmask(json.dumps(result)))
        findings.append((name, len(rows), result))
        print(f"    -> {result.get('severity')}")
        time.sleep(SECONDS_BETWEEN_CALLS)

    write_report(findings, "triage_report.md")
    print(f"\n[+] Report written: triage_report.md ({len(findings)} findings)")


if __name__ == "__main__":
    main()
